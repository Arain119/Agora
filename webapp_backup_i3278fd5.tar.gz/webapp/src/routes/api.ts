// OpenAI-compatible API Routes
import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { getState, getNextAvailableKey, addLog, validateUserToken } from '../lib/state'
import { getModelList } from '../lib/models'
import type { ChatCompletionRequest } from '../types'

const api = new Hono()

// Enable CORS for all API routes
api.use('*', cors({
  origin: '*',
  allowHeaders: ['Content-Type', 'Authorization'],
  allowMethods: ['GET', 'POST', 'OPTIONS'],
}))

// Auth middleware
api.use('*', async (c, next) => {
  const path = c.req.path
  // Skip auth for models list
  if (path === '/v1/models') {
    await next()
    return
  }

  const auth = c.req.header('Authorization')
  if (!auth) {
    return c.json({ error: { message: 'Missing Authorization header', type: 'authentication_error', code: 401 } }, 401)
  }

  const state = getState()
  const userToken = validateUserToken(state, auth)
  
  if (!userToken) {
    return c.json({ error: { message: 'Invalid or rate-limited API key', type: 'authentication_error', code: 401 } }, 401)
  }

  // Store validated token info in context
  c.set('userToken', userToken)
  await next()
})

// GET /v1/models - List available models
api.get('/v1/models', (c) => {
  const models = getModelList()
  return c.json({
    object: 'list',
    data: models,
  })
})

// POST /v1/chat/completions - Chat completion (main endpoint)
api.post('/v1/chat/completions', async (c) => {
  const state = getState()
  const startTime = Date.now()
  const userToken = c.get('userToken') as any

  let body: ChatCompletionRequest
  try {
    body = await c.req.json()
  } catch {
    return c.json({ error: { message: 'Invalid JSON body', type: 'invalid_request_error', code: 400 } }, 400)
  }

  if (!body.model) {
    return c.json({ error: { message: 'model is required', type: 'invalid_request_error', code: 400 } }, 400)
  }

  if (!body.messages || !Array.isArray(body.messages)) {
    return c.json({ error: { message: 'messages is required and must be an array', type: 'invalid_request_error', code: 400 } }, 400)
  }

  // Get available NVIDIA key
  const key = getNextAvailableKey(state)
  if (!key) {
    return c.json({ 
      error: { message: 'All API keys are rate limited. Please try again later.', type: 'rate_limit_error', code: 429 } 
    }, 429)
  }

  // Increment counters
  key.requestCount++
  key.totalRequests++
  key.lastUsed = Date.now()
  userToken.requestCount++
  userToken.totalRequests++

  const isStream = body.stream === true

  try {
    const response = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${key.key}`,
      },
      body: JSON.stringify(body),
    })

    const latency = Date.now() - startTime

    if (!response.ok) {
      const errorText = await response.text()
      let errorData: any = { message: errorText }
      try { errorData = JSON.parse(errorText) } catch {}
      
      key.failCount++
      
      addLog(state, {
        timestamp: startTime,
        model: body.model,
        keyId: key.id,
        userToken: userToken.token.substring(0, 20) + '...',
        status: response.status,
        latency,
        error: errorData?.error?.message || errorText,
      })

      return c.json({ error: errorData?.error || { message: errorText } }, response.status as any)
    }

    // Log success
    addLog(state, {
      timestamp: startTime,
      model: body.model,
      keyId: key.id,
      userToken: userToken.token.substring(0, 20) + '...',
      status: 200,
      latency,
    })

    // Handle streaming
    if (isStream) {
      c.header('Content-Type', 'text/event-stream')
      c.header('Cache-Control', 'no-cache')
      c.header('Connection', 'keep-alive')
      c.header('X-Accel-Buffering', 'no')
      
      return new Response(response.body, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
          'X-Accel-Buffering': 'no',
          'Access-Control-Allow-Origin': '*',
        },
      })
    }

    // Non-streaming response
    const data = await response.json() as any
    return c.json(data)

  } catch (err: any) {
    const latency = Date.now() - startTime
    key.failCount++
    
    addLog(state, {
      timestamp: startTime,
      model: body.model,
      keyId: key.id,
      userToken: userToken.token.substring(0, 20) + '...',
      status: 500,
      latency,
      error: err.message,
    })

    return c.json({ 
      error: { message: `Request failed: ${err.message}`, type: 'server_error', code: 500 } 
    }, 500)
  }
})

// POST /v1/completions - Text completion (legacy)
api.post('/v1/completions', async (c) => {
  const state = getState()
  const startTime = Date.now()
  const userToken = c.get('userToken') as any

  let body: any
  try {
    body = await c.req.json()
  } catch {
    return c.json({ error: { message: 'Invalid JSON body', type: 'invalid_request_error', code: 400 } }, 400)
  }

  const key = getNextAvailableKey(state)
  if (!key) {
    return c.json({ error: { message: 'All API keys are rate limited', type: 'rate_limit_error', code: 429 } }, 429)
  }

  key.requestCount++
  key.totalRequests++
  key.lastUsed = Date.now()
  userToken.requestCount++
  userToken.totalRequests++

  try {
    const response = await fetch('https://integrate.api.nvidia.com/v1/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${key.key}`,
      },
      body: JSON.stringify(body),
    })

    const latency = Date.now() - startTime
    
    if (!response.ok) {
      const errorText = await response.text()
      key.failCount++
      addLog(state, { timestamp: startTime, model: body.model || 'unknown', keyId: key.id, userToken: userToken.token.substring(0, 20) + '...', status: response.status, latency, error: errorText })
      return new Response(errorText, { status: response.status })
    }

    addLog(state, { timestamp: startTime, model: body.model || 'unknown', keyId: key.id, userToken: userToken.token.substring(0, 20) + '...', status: 200, latency })

    if (body.stream) {
      return new Response(response.body, {
        headers: { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Access-Control-Allow-Origin': '*' },
      })
    }
    const data = await response.json() as any
    return c.json(data)
  } catch (err: any) {
    return c.json({ error: { message: err.message } }, 500)
  }
})

// POST /v1/embeddings - Embeddings endpoint
api.post('/v1/embeddings', async (c) => {
  const state = getState()
  const startTime = Date.now()
  const userToken = c.get('userToken') as any

  let body: any
  try {
    body = await c.req.json()
  } catch {
    return c.json({ error: { message: 'Invalid JSON body' } }, 400)
  }

  const key = getNextAvailableKey(state)
  if (!key) {
    return c.json({ error: { message: 'All API keys are rate limited' } }, 429)
  }

  key.requestCount++
  key.totalRequests++
  key.lastUsed = Date.now()
  userToken.requestCount++
  userToken.totalRequests++

  try {
    const response = await fetch('https://integrate.api.nvidia.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${key.key}`,
      },
      body: JSON.stringify(body),
    })

    const latency = Date.now() - startTime
    
    if (!response.ok) {
      const errorText = await response.text()
      key.failCount++
      addLog(state, { timestamp: startTime, model: body.model || 'embed', keyId: key.id, userToken: userToken.token.substring(0, 20) + '...', status: response.status, latency, error: errorText })
      return new Response(errorText, { status: response.status })
    }

    addLog(state, { timestamp: startTime, model: body.model || 'embed', keyId: key.id, userToken: userToken.token.substring(0, 20) + '...', status: 200, latency })
    const data = await response.json() as any
    return c.json(data)
  } catch (err: any) {
    return c.json({ error: { message: err.message } }, 500)
  }
})

export default api
